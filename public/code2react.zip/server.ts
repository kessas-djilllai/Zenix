import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware to parse JSON
  app.use(express.json({ limit: "50mb" }));

  // Helper for Github API proxy
  const githubApi = async (urlPath: string, options: RequestInit = {}) => {
    // Keep in mind that we're proxying the github token safely
    const token = process.env.GITHUB_TOKEN || "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"; 
    const url = `https://api.github.com${urlPath.startsWith('/') ? urlPath : '/' + urlPath}`;
    
    const res = await fetch(url + (options.method === 'GET' ? (url.includes('?') ? '&' : '?') + 't=' + Date.now() : ''), {
      ...options,
      headers: {
        "Authorization": `token ${token}`,
        "Accept": "application/vnd.github.v3+json",
        ...((options.body && typeof options.body === 'string') ? { "Content-Type": "application/json" } : {}),
        "User-Agent": "React-App-Proxy",
        ...(options.headers || {})
      }
    });

    const isJson = res.headers.get("content-type")?.includes("application/json");
    const data = isJson ? await res.json() : await res.text();
    
    return { status: res.status, data };
  };

  // API Routes
  app.get("/api/github/contents", async (req, res) => {
    const { owner, repo, path: filePath = '' } = req.query;
    if (!owner || !repo) return res.status(400).json({ error: "Missing owner or repo" });
    const { status, data } = await githubApi(`/repos/${owner}/${repo}/contents/${filePath}`);
    res.status(status).json(data);
  });

  app.get("/api/github/actions", async (req, res) => {
    const { owner, repo } = req.query;
    if (!owner || !repo) return res.status(400).json({ error: "Missing owner or repo" });
    const { status, data } = await githubApi(`/repos/${owner}/${repo}/actions/runs`);
    res.status(status).json(data);
  });

  app.delete("/api/github/actions/:runId", async (req, res) => {
    const { owner, repo } = req.query;
    const { runId } = req.params;
    if (!owner || !repo) return res.status(400).json({ error: "Missing owner or repo" });
    const { status } = await githubApi(`/repos/${owner}/${repo}/actions/runs/${runId}`, { method: 'DELETE' });
    res.json({ success: status === 200 || status === 204 });
  });

  app.post("/api/github/rename", async (req, res) => {
    const { owner, repo, old_path, new_path, sha } = req.body;
    if (!owner || !repo || !old_path || !new_path || !sha) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    // Get old file content
    const { status: getStatus, data: fileData } = await githubApi(`/repos/${owner}/${repo}/contents/${old_path}`);
    
    if (getStatus === 200 && fileData.content) {
      // Create new file
      const { status: createStatus, data: createData } = await githubApi(`/repos/${owner}/${repo}/contents/${new_path}`, {
        method: 'PUT',
        body: JSON.stringify({
          message: `Renamed ${old_path} to ${new_path}`,
          content: fileData.content.replace(/\n/g, "")
        })
      });

      if (createStatus === 200 || createStatus === 201) {
        // Delete old file
        await githubApi(`/repos/${owner}/${repo}/contents/${old_path}`, {
          method: 'DELETE',
          body: JSON.stringify({
            message: `Deleted old file after rename`,
            sha
          })
        });
        return res.json({ success: true });
      }
      return res.status(createStatus).json({ success: false, error: 'Failed to create new file', details: createData });
    }
    res.status(getStatus).json({ success: false, error: 'Failed to read old file', details: fileData });
  });

  app.delete("/api/github/delete", async (req, res) => {
    const { owner, repo, path: targetPath, sha, type } = req.body;
    
    if (type === 'dir' || !targetPath || targetPath === '/') {
      // Recursive delete folder or whole repo
      const deleteDir = async (dirPath: string) => {
        const url = dirPath ? `/repos/${owner}/${repo}/contents/${dirPath}` : `/repos/${owner}/${repo}/contents`;
        const { status, data } = await githubApi(url);
        
        if (status === 200 && Array.isArray(data)) {
          for (const item of data) {
            if (item.type === 'dir') {
              await deleteDir(item.path);
            } else {
              await githubApi(`/repos/${owner}/${repo}/contents/${item.path}`, {
                method: 'DELETE',
                body: JSON.stringify({
                  message: 'Deleted via Web UI',
                  sha: item.sha
                })
              });
            }
          }
        }
      };
      
      await deleteDir(targetPath || '');
      return res.json({ success: true });
    } else {
      // Delete single file
      const { status, data } = await githubApi(`/repos/${owner}/${repo}/contents/${targetPath}`, {
        method: 'DELETE',
        body: JSON.stringify({
          message: 'Deleted file via Web UI',
          sha
        })
      });
      return res.json({ success: status === 200 || status === 201, details: data });
    }
  });

  app.post("/api/github/upload", async (req, res) => {
    const { owner, repo, path: filePath, sha, content } = req.body;
    const bodyArgs: any = {
      message: sha ? 'Edited via Web UI' : 'Uploaded via Web UI',
      content
    };
    if (sha) bodyArgs.sha = sha;

    const { status, data } = await githubApi(`/repos/${owner}/${repo}/contents/${filePath}`, {
      method: 'PUT',
      body: JSON.stringify(bodyArgs)
    });
    
    res.json({ success: status === 200 || status === 201, details: data });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // Use *all for Express v5, or * for Express v4. We are using v4 (version ^4.21.2)
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
